Thanks for your interest in my font!

Friendly Scribbles includes uppercase and lowercase letters, numbers, common symbols, and lots of accented letters.​​

You can use this font for free with attribution, but a donation is much appreciated
For attribution please say something along the lines of "friendly scribbles font by @kmlgames​", or however your credits list is formatted.

If you notice any missing characters that you think should be in the font, or any other mistakes, please send an email to yes@kml.rocks.
I tried to make sure I included the most common latin-based characters, but I might've missed some anyway.
Any such emails are much appreciated!

If you're a developer, artist, or creator of any kind, and  you've used my font, please let me know! I'd love to see it in use.